package modelo;

public class MotoBoy extends Funcionario{

	int idMotoBoy;
	int idFuncionario;
	
	public void setIdMotoBoy(int id){
		this.idMotoBoy = id;
	}
	
	public int getIdMotoBoy(){
		return this.idMotoBoy;
	}
	
	public void setIdFuncionario(int id) {
		this.idFuncionario = id;
	}
	
	public int getIdFuncionario() {
		return this.idFuncionario;
	}
}
